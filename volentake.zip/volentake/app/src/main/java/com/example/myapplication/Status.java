package com.example.myapplication;

public enum Status {
    CANCELED,
    REJECTED,
    WAITING,
    APPROVED
}
