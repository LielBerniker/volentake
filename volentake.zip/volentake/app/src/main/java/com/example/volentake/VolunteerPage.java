package com.example.volentake;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity Volunteer Home Page
 */
public class VolunteerPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volunteer_page);
    }
}